pyspark --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.4.0 --jars /Users/arunkumar/Downloads/mysql-connector-j-9.0.0/mysql-connector-j-9.0.0.jar

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, explode, split
from pyspark.sql.functions import from_json, schema_of_json,to_timestamp
from pyspark.sql.types import StructType, StructField, StringType, DateType,IntegerType
from pyspark.sql.functions import udf
from pyspark.sql.functions import lit
from pyspark.sql.functions import split
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.regression import LinearRegression
import pyspark.sql.functions
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.mllib.evaluation import BinaryClassificationMetrics
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.regression import RandomForestRegressor
from pyspark.ml.feature import VectorIndexer
from pyspark.ml.evaluation import RegressionEvaluator
import findspark
from pyspark.ml.tuning import ParamGridBuilder, TrainValidationSplit
findspark.init()

spark = SparkSession.builder \
    .appName("SparkApp") \
    .config("spark.jars.packages", "org.apache.spark:spark-sql-kafka-0-10_2.12:3.4.0, mysql:mysql-connector-java:8.0.33") \
    .master("local[*]") \
    .getOrCreate()
    

# Define JSON schema
schema = StructType([
    StructField("datetime", StringType(), True),  # String type initially
    StructField("season", StringType(), True),
    StructField("holiday", StringType(), True),
    StructField("workingday", StringType(), True),
    StructField("weather", StringType(), True),
	StructField("temp", StringType(), True),
	StructField("atemp", StringType(), True),
	StructField("humidity", StringType(), True),
	StructField("windspeed", StringType(), True),
	StructField("casual", StringType(), True),
	StructField("registered", StringType(), True),
	StructField("count", StringType(), True)
])

# Read data from Kafka
df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "edureka1") \
    .load()

df = df.select(from_json(col("value").cast("string"), schema).alias("json")) \
    .select(
        to_timestamp(col("json.datetime"), "yyyy-MM-dd HH:mm:ss").alias("datetime"),  # Convert to TimestampType
        col("json.season").alias("season"),
        col("json.holiday").cast("integer").alias("holiday"),
        col("json.workingday").cast("integer").alias("workingday"),
        col("json.weather").cast("integer").alias("weather"),
        col("json.atemp").cast("double").alias("atemp"),
        col("json.temp").cast("double").alias("temp"),
        col("json.humidity").cast("integer").alias("humidity"),
        col("json.windspeed").cast("double").alias("windspeed"),
        col("json.casual").cast("integer").alias("casual"),
        col("json.registered").cast("integer").alias("registered"),
        col("json.count").cast("integer").alias("count"),
        current_timestamp().alias("timestamp") 
    )

    
def valueToCategory(value, encoding_index):
   if(value == encoding_index):
      return 1
   else:
    return 0
    
    
udfValueToCategory = udf(valueToCategory, IntegerType())
df_encode = (df.withColumn("season_1", udfValueToCategory(col('season'),lit(1)))
						 .withColumn("season_2", udfValueToCategory(col('season'),lit(2)))
						 .withColumn("season_3", udfValueToCategory(col('season'),lit(3)))
						 .withColumn("season_4", udfValueToCategory(col('season'),lit(4))))
df_encode = df_encode.drop('season')
     
df_encode = (df_encode.withColumn("weather_1", udfValueToCategory(col('weather'),lit(1)))
                     .withColumn("weather_2", udfValueToCategory(col('weather'),lit(2)))
                     .withColumn("weather_3", udfValueToCategory(col('weather'),lit(3)))
                     .withColumn("weather_4", udfValueToCategory(col('weather'),lit(4))))
df_encode = df_encode.drop('weather')
df_encode = df_encode.withColumn('hour',  split(split(df_encode['datetime'], ' ')[1], ':')[0].cast('int'))
df_encode = df_encode.withColumn('month', split(split(df_encode['datetime'], ' ')[0], '-')[0].cast('int'))
df_encode = df_encode.withColumn('day', split(split(df_encode['datetime'], ' ')[0], '-')[1].cast('int'))
df_encode = df_encode.withColumn('year', split(split(df_encode['datetime'], ' ')[0], '-')[2].cast('int'))

df_encode = df_encode.drop('datetime')
df_encode = df_encode.withColumnRenamed("count", "label")


assembler = VectorAssembler(
    inputCols=["holiday","workingday","temp","atemp","humidity","windspeed","casual","registered","label","season_1","season_2","season_3","season_4","weather_1","weather_2","weather_3","weather_4", "hour", "month", "day", "year"],
    outputCol="features")
    

test_output = assembler.transform(df_encode)


from pyspark.ml.regression import RandomForestRegressionModel
loaded_model = RandomForestRegressionModel.load("file:///Users/arunkumar/saved_model")



predictions = loaded_model.transform(test_output).select("features", "label", "prediction")



query = predictions.writeStream \
    .outputMode("append") \
    .format("console") \
    .start()

mysql_url = "jdbc:mysql://localhost:3306/customers"
mysql_properties = {
	 "user": "root",
	 "password": "mysql",
	 "driver": "com.mysql.cj.jdbc.Driver"
}


def write_to_mysql(df_t, epoch_id):
	 df1 = df_t.withColumn("epoch_id", lit(epoch_id))
	 df1.write.mode("append").jdbc(mysql_url, "edureka_spark", properties=mysql_properties)


query = predictions.writeStream.foreachBatch(write_to_mysql).outputMode("append").start()    
      




